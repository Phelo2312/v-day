WAHDJ website – files ready for your own hosting
=================================================

WHAT IS IN THIS FOLDER
  index.html            the whole website (all pages)
  assets/tailwind.css   layout styles
  images/               all photos, logos and badges

Keep the three together in the same folder. Nothing loads from Canva or any other outside service.


HOW TO PUT IT ONLINE (choose one)
  Netlify (free, easiest)
    1. Go to app.netlify.com/drop
    2. Drag this whole folder onto the page. The site goes live on a netlify.app address.
    3. Site settings > Domain management to connect your own domain (for example wahdj.com).

  Your hosting company (cPanel or similar)
    1. Open File Manager and go to public_html (or www).
    2. Upload index.html, the assets folder and the images folder.

  GitHub Pages
    1. Create a repository, upload the folder contents, then Settings > Pages > Deploy from branch.

Always upload the CONTENTS of this folder so index.html sits at the top level of the site.


CONTACT FORM – receive requests in your inbox (recommended)
  The form works straight away: it opens the visitor's email app with the request written out,
  addressed to proposals@wahdj.com. To receive submissions automatically instead:
    1. Create a free form at formspree.io (or web3forms.com) for proposals@wahdj.com.
    2. Copy the form endpoint URL (looks like https://formspree.io/f/abcdwxyz).
    3. Open index.html in a text editor, search for  const FORM_ENDPOINT=''  and paste the URL
       between the quotes. For Web3Forms, also paste your access key into FORM_ACCESS_KEY.
    4. Save and upload index.html again.
  After that, visitors see the Thank-you page and the request arrives by email.


STILL TO DO BEFORE LAUNCH (left as you asked)
  - [PLACEHOLDER] notes are still visible on: homepage rating cards (Roznah, Living Building
    Challenge and Al Sa'fat roles), the footer (Facebook/Instagram), the contact form note,
    the Thank-you page, and the Privacy policy, Terms of use and Accessibility pages.
  - The contact-form note still says submissions go to a Canva Sheet; on your own hosting
    they go by email (see above), so update that sentence.
  - Ebtihal Mohamed's team photo (her card shows "EM" until a photo is added).
